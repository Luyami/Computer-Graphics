Um tutorial como compilar (:
(com o passar das atividades, posso fazer um instalador para otimizar esse processo)

As bibliotecas usadas foram SDL2 (gerenciamento de janelas) e glew (interface com o opengl). Para compilar o código, é necessário linkar com essas duas bibliotecas.
Versão do sdl2 usada: https://github.com/libsdl-org/SDL/releases/tag/release-2.30.8
Versão do glew usada: https://sourceforge.net/projects/glew/files/glew/2.1.0/

Nessa pasta, tem os arquivos necessários para compilar em Windows x64 (se for algum outro sistema operacional/arquitetura, é só baixar as bibliotecas correspondentes nos dois sites acima).

No Windows x64, o código pode ser compilado da seguinte forma:

Usando gcc: gcc -o scene scene.cpp -L"glew_lib" -L"sdl2_lib" -lSDL2 -lglew32 -lopengl32 -lstdc++
Usando g++: g++ -o scene scene.cpp -L"glew_lib" -L"sdl2_lib" -lSDL2 -lglew32 -lopengl32 -lstdc++