#define SDL_MAIN_HANDLED

#include "sdl2/i686-w64-mingw32/include/SDL2/SDL.h"
#include "glew/include/GL/glew.h"

#include <stdio.h>
#include <iostream>

#include <math.h>

#include <chrono>
#include <thread>

class Vector3{
    private:
        float x;
        float y;
        float z;

    public:
        Vector3(){
            x = 0; y = 0; z = 0;
        }

        Vector3(float x, float y, float z){
            this->x = x;
            this->y = y;
            this->z = z;
        }
    
        int getX() {return x;}
        int getY() {return y;}
        int getZ() {return z;}

        float cartesianDot(const Vector3& other){
            return x*other.x + y*other.y + z*other.z;
        }

        float magnitude(){
            return sqrt(pow(x, 2) + pow(y, 2) + pow(z, 2));
        }

        Vector3 normalize(){
            return *this/magnitude();
        }

        friend std::ostream& operator<<(std::ostream& str, Vector3 const& o);
        friend Vector3 operator+(const Vector3& o1, const Vector3& o2);
        friend Vector3 operator-(const Vector3& o1, const Vector3& o2);
        friend Vector3 operator-(const Vector3& o);
        friend Vector3 operator/(const Vector3& o1, const Vector3& o2);
        friend Vector3 operator/(const Vector3& o, float n);
        friend Vector3 operator*(const Vector3& o, float n);
};
std::ostream& operator<<(std::ostream& str, Vector3 const& o) { 
    str << '(' << o.x << ',' << o.y << ',' << o.z << ')';

    return str;
}
Vector3 operator+(const Vector3& o1, const Vector3& o2){
    return Vector3(o1.x + o2.x, o1.y + o2.y, o1.z + o2.z);
}
Vector3 operator-(const Vector3& o1, const Vector3& o2){
    return Vector3(o1.x - o2.x, o1.y - o2.y, o1.z - o2.z);
}
Vector3 operator-(const Vector3& o){
    return Vector3(-o.x, -o.y, -o.z);
}
Vector3 operator/(const Vector3& o1, const Vector3& o2){
    return Vector3(o1.x/o2.x, o1.y/o2.y, o1.z/o2.z);
}
Vector3 operator/(const Vector3& o, float n){
    return Vector3(o.x/n, o.y/n, o.z/n);
}
Vector3 operator*(const Vector3& o, float n){
    return Vector3(o.x*n, o.y*n, o.z*n);
}

class HitResult{
    public:
        bool hit;
        bool negativeHit;
        Vector3 hitPoint;

        HitResult(){
            this->hitPoint = Vector3(0,0,0);
            this->hit = false;
            this->negativeHit = false;
        }

        HitResult(Vector3 hitPoint, bool hit, bool negativeHit){
            this->hitPoint = hitPoint;
            this->hit = hit;
            this->negativeHit = negativeHit;
        }
};

class Sphere{
    private:
        Vector3 center;
        float ray;

    public:
        Sphere(Vector3 center, float ray){
            this->center = center;
            this->ray = ray;
        }

        HitResult getHit(Vector3 initialPos, Vector3 dir){
            Vector3 v = initialPos - center;

            float a = dir.cartesianDot(dir);
            float b = 2*dir.cartesianDot(v);
            float c = v.cartesianDot(v) - pow(ray,2);

            float delta = pow(b,2) - 4*a*c;
            HitResult result = HitResult();

            if (delta == 0){
                float t = (-b)/(2*a);

                result.hit = true;
                if (t < 0) result.negativeHit = true;
                
                result.hitPoint = initialPos + dir*t;
            }
            else if(delta > 0){
                float t1 = (-b + sqrt(delta))/(2*a);
                float t2 = (-b - sqrt(delta))/(2*a);
                
                float minT = std::min(t1,t2);

                result.hit = true;
                if (minT < 0) result.negativeHit = true;

                result.hitPoint = initialPos + dir*minT;
            }
            
            return result;
        }
};

void renderSphere(SDL_Window* window, Sphere s, float frameWidth, float frameHeight, Vector3 framePos, int frameRows, int frameColumns, Vector3 eyePos){
    auto start = std::chrono::high_resolution_clock::now();
    float dX = frameWidth/frameColumns;
    float dY = frameHeight/frameRows;

    glBegin(GL_POINTS); //Começar a desenhar no back buffer
    for (int r = 0; r <= frameRows; ++r){
        float frame_pixelY = framePos.getY() + frameHeight/2 - dY/2 - r*dY; 

        for (int c = 0; c <= frameColumns; ++c){
            
            float frame_pixelX = framePos.getX() - frameWidth/2 + dX/2 + c*dX;

            Vector3 frame_pixelCoord = Vector3(frame_pixelX, frame_pixelY, framePos.getZ());
            Vector3 rayDir = (frame_pixelCoord - eyePos).normalize();

            HitResult hitResult = s.getHit(eyePos, rayDir);         

            if (!hitResult.hit || hitResult.negativeHit){ //Se não houver interseção...
                glColor3f(100.0f/255, 100.0f/255, 100.0f/255);
                glVertex2f(-1.0f + (2.0f*c)/(frameColumns), 1.0f - (2.0f*(r))/(frameRows));
            }
            else{
                glColor3f(1.0f, 0.0f, 0.0f);
                glVertex2f(-1.0f + (2.0f*c)/(frameColumns), 1.0f - (2.0f*(r))/(frameRows));
            }
        }
    }
    glEnd(); //Terminar de desenhar no back buffer

    SDL_GL_SwapWindow(window); //Transferir o back buffer para o front buffer (desenhar a esfera na janela do sdl)
    
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> duration = end - start;
    std::cout << "A esfera renderizou em: " << duration.count() << " segundos!\n";
}

int main(int argc, char* argv[]) {
    //Dimensões do canvas
    int screenResWidth = 800;
    int screenResHeight = 800;
    //

    //Setando o olho
    Vector3 eyePos = Vector3(0,0,0);
    //

    //Setando o frame
    float wFrame = 10.0f;
    float hFrame = wFrame / (screenResWidth/screenResHeight); //Esse cálculo é para o tamanho do frame ficar na mesma proporção da resolução da janela
    float dFrame = 10.0f;

    int nCols = screenResWidth;
    int nRows = screenResHeight;

    Vector3 framePos = Vector3(0, 0, -dFrame);
    //

    //Setando a esfera
    float rSphere = 2.0f;
    Sphere s = Sphere(Vector3(0.0f, 0.0f, -(dFrame + rSphere)), rSphere);
    //

    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        return -1;
    }

    //Criando a janela do sdl
    SDL_Window* window = SDL_CreateWindow("Esfera", 
                                          SDL_WINDOWPOS_CENTERED, 
                                          SDL_WINDOWPOS_CENTERED, 
                                          screenResWidth, screenResHeight, 
                                          SDL_WINDOW_OPENGL | SDL_WINDOW_SHOWN);
    if (!window) {
        SDL_Quit();
        return -1;
    }

    SDL_GLContext glContext = SDL_GL_CreateContext(window);
    if (!glContext) {
        SDL_DestroyWindow(window);
        SDL_Quit();
        return -1;
    }

    glewExperimental = GL_TRUE;
    GLenum err = glewInit();
    if (err != GLEW_OK) {
        SDL_GL_DeleteContext(glContext);
        SDL_DestroyWindow(window);
        SDL_Quit();
        return -1;
    }

    renderSphere(window, s, wFrame, hFrame, framePos, nRows, nCols, eyePos);

    bool running = true;
    SDL_Event event;

    //Um sistema de movimentação básico, só para ficar um pouco mais interessante
    while (running) {
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) {
                running = false;
            }
            else if (event.type == SDL_KEYDOWN){
                if (event.key.keysym.sym == SDLK_s){ //Ir para trás
                    eyePos = eyePos + Vector3(0, 0, 1.0f);
                    framePos = framePos + Vector3(0, 0, 1.0f);

                    renderSphere(window, s, wFrame, hFrame, framePos, nRows, nCols, eyePos);
                }
                else if (event.key.keysym.sym == SDLK_w){ //Ir para frente
                    eyePos = eyePos + Vector3(0, 0, -1.0f);
                    framePos = framePos + Vector3(0, 0, -1.0f);

                    renderSphere(window, s, wFrame, hFrame, framePos, nRows, nCols, eyePos);
                } 
                else if (event.key.keysym.sym == SDLK_z){ //Ir para cima
                    eyePos = eyePos + Vector3(0, 1.0f, 0);
                    framePos = framePos + Vector3(0, 1.0f, 0);

                    renderSphere(window, s, wFrame, hFrame, framePos, nRows, nCols, eyePos);
                }
                else if (event.key.keysym.sym == SDLK_c){ //Ir para baixo
                    eyePos = eyePos + Vector3(0, -1.0f, 0);
                    framePos = framePos + Vector3(0, -1.0f, 0);

                    renderSphere(window, s, wFrame, hFrame, framePos, nRows, nCols, eyePos);
                }
                else if (event.key.keysym.sym == SDLK_d){ //Ir para direita
                    eyePos = eyePos + Vector3(1.0f, 0, 0);
                    framePos = framePos + Vector3(1.0f, 0, 0);

                    renderSphere(window, s, wFrame, hFrame, framePos, nRows, nCols, eyePos);
                } 
                else if (event.key.keysym.sym == SDLK_a){ //Ir para esquerda
                    eyePos = eyePos + Vector3(-1.0f, 0, 0);
                    framePos = framePos + Vector3(-1.0f, 0, 0);

                    renderSphere(window, s, wFrame, hFrame, framePos, nRows, nCols, eyePos);
                } 
            }
        }
    }

    SDL_GL_DeleteContext(glContext);
    SDL_DestroyWindow(window);
    SDL_Quit();

    return 0;
}